// DOMの読み込み完了後に実行
document.addEventListener('DOMContentLoaded', function() {
    // モバイルメニューの切り替え
    const mobileMenuBtn = document.getElementById('mobileMenuBtn');
    const mainNav = document.getElementById('mainNav');
    const menuIcon = mobileMenuBtn.querySelector('.menu-icon');
    
    mobileMenuBtn.addEventListener('click', function() {
        mainNav.classList.toggle('active');
        // アイコンの切り替え
        if (mainNav.classList.contains('active')) {
            menuIcon.src = 'images/icons/close.png';
        } else {
            menuIcon.src = 'images/icons/menu.png';
        }
    });
    
    // ヒーロースライダー
    const heroSlides = document.querySelectorAll('.hero-slide');
    const prevSlideBtn = document.getElementById('prevSlide');
    const nextSlideBtn = document.getElementById('nextSlide');
    let currentSlide = 0;
    
    // スライドを表示する関数
    function showSlide(index) {
        // すべてのスライドを非表示
        heroSlides.forEach(slide => {
            slide.classList.remove('active');
        });
        
        // インデックスの調整（循環）
        if (index >= heroSlides.length) {
            currentSlide = 0;
        } else if (index < 0) {
            currentSlide = heroSlides.length - 1;
        } else {
            currentSlide = index;
        }
        
        // 現在のスライドを表示
        heroSlides[currentSlide].classList.add('active');
    }
    
    // 前のスライドへ
    prevSlideBtn.addEventListener('click', function() {
        showSlide(currentSlide - 1);
    });
    
    // 次のスライドへ
    nextSlideBtn.addEventListener('click', function() {
        showSlide(currentSlide + 1);
    });
    
    // 自動スライド（5秒間隔）
    let slideInterval = setInterval(function() {
        showSlide(currentSlide + 1);
    }, 5000);
    
    // マウスホバーで自動スライドを一時停止
    const heroSlider = document.querySelector('.hero-slider');
    heroSlider.addEventListener('mouseenter', function() {
        clearInterval(slideInterval);
    });
    
    heroSlider.addEventListener('mouseleave', function() {
        slideInterval = setInterval(function() {
            showSlide(currentSlide + 1);
        }, 5000);
    });
    
    // カレンダーの生成
    const calendar = document.getElementById('calendar');
    const prevMonthBtn = document.getElementById('prevMonth');
    const nextMonthBtn = document.getElementById('nextMonth');
    const daysOfWeek = ['日', '月', '火', '水', '木', '金', '土'];
    
    let currentDate = new Date(2023, 10, 1); // 2023年11月
    
    // カレンダーを生成する関数
    function generateCalendar(date) {
        // カレンダーをクリア
        calendar.innerHTML = '';
        
        // 曜日のヘッダーを追加
        daysOfWeek.forEach(day => {
            const dayElement = document.createElement('div');
            dayElement.className = 'calendar-day';
            dayElement.textContent = day;
            calendar.appendChild(dayElement);
        });
        
        const year = date.getFullYear();
        const month = date.getMonth();
        const firstDay = new Date(year, month, 1);
        const lastDay = new Date(year, month + 1, 0);
        const today = new Date();
        
        // 月と年を表示
        const monthYearElement = document.querySelector('.calendar-header h3');
        const monthNames = ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'];
        monthYearElement.textContent = `${year}年 ${monthNames[month]}`;
        
        // 最初の日の前の空白を追加
        for (let i = 0; i < firstDay.getDay(); i++) {
            const emptyDay = document.createElement('div');
            emptyDay.className = 'calendar-date';
            calendar.appendChild(emptyDay);
        }
        
        // イベントがある日（サンプル）
        const eventDays = [5, 12, 15, 20, 22, 25];
        
        // 日付を追加
        for (let day = 1; day <= lastDay.getDate(); day++) {
            const dateElement = document.createElement('div');
            dateElement.className = 'calendar-date';
            
            const dateNumber = document.createElement('div');
            dateNumber.className = 'date-number';
            dateNumber.textContent = day;
            dateElement.appendChild(dateNumber);
            
            // 今日の日付をハイライト
            if (year === today.getFullYear() && month === today.getMonth() && day === today.getDate()) {
                dateElement.classList.add('today');
            }
            
            // イベントがある日をマーク
            if (eventDays.includes(day)) {
                dateElement.classList.add('event');
                const eventDot = document.createElement('div');
                eventDot.className = 'event-dot';
                dateElement.appendChild(eventDot);
                
                // イベント情報を追加
                let eventTitle = '';
                if (day === 5) eventTitle = '健康診断';
                else if (day === 12) eventTitle = '子育て相談会';
                else if (day === 15) eventTitle = '市議会定例会';
                else if (day === 20) eventTitle = 'マリーナ説明会';
                else if (day === 22) eventTitle = '防災訓練';
                else if (day === 25) eventTitle = 'ビーチ清掃';
                
                dateElement.title = `${day}日: ${eventTitle}`;
            }
            
            // 日付クリック時の処理
            dateElement.addEventListener('click', function() {
                if (eventDays.includes(day)) {
                    alert(`${year}年${month + 1}月${day}日\nイベントがあります`);
                }
            });
            
            calendar.appendChild(dateElement);
        }
    }
    
    // 初期カレンダー生成
    generateCalendar(currentDate);
    
    // 前月ボタン
    prevMonthBtn.addEventListener('click', function() {
        currentDate.setMonth(currentDate.getMonth() - 1);
        generateCalendar(currentDate);
    });
    
    // 次月ボタン
    nextMonthBtn.addEventListener('click', function() {
        currentDate.setMonth(currentDate.getMonth() + 1);
        generateCalendar(currentDate);
    });
    
    // 検索ボタン
    const searchBtn = document.getElementById('searchBtn');
    searchBtn.addEventListener('click', function() {
        const searchTerm = prompt('検索したいキーワードを入力してください:');
        if (searchTerm && searchTerm.trim() !== '') {
            alert(`「${searchTerm}」で検索します。\n（実際のサイトでは検索結果ページに移動します。）`);
        }
    });
    
    // 多言語ボタン
    const languageBtn = document.getElementById('languageBtn');
    languageBtn.addEventListener('click', function() {
        alert('多言語対応ページに移動します。\n（英語、中国語、韓国語などに対応予定です。）');
    });
    
    // ヒーローアクションボタン
    const heroInfoBtn = document.getElementById('heroInfoBtn');
    const heroDownloadBtn = document.getElementById('heroDownloadBtn');
    
    heroInfoBtn.addEventListener('click', function() {
        window.location.href = 'about/index.html';
    });
    
    heroDownloadBtn.addEventListener('click', function() {
        alert('申請書ダウンロードページに移動します。');
        // 実際は以下のようにする
        // window.location.href = 'procedures/index.html';
    });
    
    // ニュースアイテムクリック時の処理
    const newsItems = document.querySelectorAll('.news-item');
    newsItems.forEach(item => {
        item.addEventListener('click', function() {
            const newsText = this.querySelector('strong').textContent;
            alert(`「${newsText}」\n\n詳細ページを表示します。`);
        });
    });
    
    // フェードインアニメーション（スクロール時に要素を表示）
    function fadeInOnScroll() {
        const elements = document.querySelectorAll('.feature-card, .content-column, .gallery-item');
        
        elements.forEach(element => {
            const elementTop = element.getBoundingClientRect().top;
            const elementVisible = 150;
            
            if (elementTop < window.innerHeight - elementVisible) {
                element.style.opacity = '1';
                element.style.transform = 'translateY(0)';
            }
        });
    }
    
    // 初期状態で要素を非表示に
    document.querySelectorAll('.feature-card, .content-column, .gallery-item').forEach(element => {
        element.style.opacity = '0';
        element.style.transform = 'translateY(20px)';
        element.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
    });
    
    // スクロールイベント
    window.addEventListener('scroll', fadeInOnScroll);
    
    // 初期表示時にも実行
    fadeInOnScroll();
    
    // 画像ギャラリーの拡大表示（簡易版）
    const galleryItems = document.querySelectorAll('.gallery-item');
    galleryItems.forEach(item => {
        item.addEventListener('click', function() {
            const imgSrc = this.querySelector('img').src;
            const caption = this.querySelector('.gallery-caption').textContent;
            
            // モーダルを作成
            const modal = document.createElement('div');
            modal.style.cssText = `
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background-color: rgba(0,0,0,0.9);
                display: flex;
                justify-content: center;
                align-items: center;
                z-index: 2000;
                cursor: pointer;
            `;
            
            const modalContent = document.createElement('div');
            modalContent.style.cssText = `
                max-width: 90%;
                max-height: 90%;
                position: relative;
            `;
            
            const modalImg = document.createElement('img');
            modalImg.src = imgSrc;
            modalImg.style.cssText = `
                max-width: 100%;
                max-height: 80vh;
                border-radius: 8px;
            `;
            
            const modalCaption = document.createElement('div');
            modalCaption.textContent = caption;
            modalCaption.style.cssText = `
                color: white;
                text-align: center;
                margin-top: 15px;
                font-size: 1.2rem;
                font-weight: bold;
            `;
            
            modalContent.appendChild(modalImg);
            modalContent.appendChild(modalCaption);
            modal.appendChild(modalContent);
            document.body.appendChild(modal);
            
            // クリックでモーダルを閉じる
            modal.addEventListener('click', function() {
                document.body.removeChild(modal);
            });
        });
    });
});