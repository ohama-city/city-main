// 申請ページの機能
document.addEventListener('DOMContentLoaded', function() {
    // 検索機能
    const searchInput = document.getElementById('procedureSearch');
    const searchBtn = document.getElementById('searchProcedureBtn');
    const searchTags = document.querySelectorAll('.search-tag');
    const procedureItems = document.querySelectorAll('.procedure-item');
    
    // 検索タグをクリックしたとき
    searchTags.forEach(tag => {
        tag.addEventListener('click', function() {
            const searchTerm = this.getAttribute('data-tag');
            searchInput.value = searchTerm;
            searchProcedures(searchTerm);
        });
    });
    
    // 検索ボタンをクリックしたとき
    searchBtn.addEventListener('click', function() {
        const searchTerm = searchInput.value.trim();
        if (searchTerm) {
            searchProcedures(searchTerm);
        }
    });
    
    // 検索入力でEnterキーを押したとき
    searchInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            const searchTerm = searchInput.value.trim();
            if (searchTerm) {
                searchProcedures(searchTerm);
            }
        }
    });
    
    // 申請手続きを検索する関数
    function searchProcedures(searchTerm) {
        const searchLower = searchTerm.toLowerCase();
        let found = false;
        
        procedureItems.forEach(item => {
            const title = item.querySelector('h3').textContent.toLowerCase();
            const description = item.querySelector('.procedure-description').textContent.toLowerCase();
            const category = item.getAttribute('data-category');
            const tags = item.getAttribute('data-tags').toLowerCase();
            
            // タイトル、説明、カテゴリ、タグを検索
            if (title.includes(searchLower) || 
                description.includes(searchLower) || 
                category.includes(searchLower) || 
                tags.includes(searchLower)) {
                item.style.display = 'block';
                found = true;
            } else {
                item.style.display = 'none';
            }
        });
        
        // 検索結果がない場合のメッセージ
        if (!found && searchTerm) {
            alert(`「${searchTerm}」に一致する申請手続きが見つかりませんでした。`);
        }
    }
    
    // 「詳細を見る」ボタンの処理
    const detailBtns = document.querySelectorAll('.procedure-detail-btn');
    const modal = document.getElementById('procedureModal');
    const modalClose = document.getElementById('modalClose');
    const modalTitle = document.getElementById('modalTitle');
    const modalBody = document.getElementById('modalBody');
    const modalOnlineBtn = document.getElementById('modalOnlineBtn');
    const modalDownloadBtn = document.getElementById('modalDownloadBtn');
    
    let currentProcedure = null;
    
    detailBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const procedureItem = this.closest('.procedure-item');
            const title = procedureItem.querySelector('h3').textContent;
            const description = procedureItem.querySelector('.procedure-description').textContent;
            const category = procedureItem.getAttribute('data-category');
            const onlineAvailable = procedureItem.querySelector('.procedure-badge.online') !== null;
            const downloadBtn = procedureItem.querySelector('.btn-outline');
            const onlineBtn = procedureItem.querySelector('a[href*="online-apply"]');
            
            // モーダルの内容を設定
            modalTitle.textContent = title;
            
            const details = procedureItem.querySelector('.procedure-details').cloneNode(true);
            
            modalBody.innerHTML = `
                <div class="modal-description">
                    <h4>手続きの説明</h4>
                    <p>${description}</p>
                </div>
                <div class="modal-details">
                    <h4>詳細情報</h4>
                    ${details.innerHTML}
                </div>
                <div class="modal-requirements">
                    <h4>必要書類</h4>
                    <ul>
                        <li>本人確認書類（運転免許証、パスポートなど）</li>
                        <li>印鑑（申請内容によって異なります）</li>
                        <li>申請書（窓口で配布またはダウンロード）</li>
                        <li>手数料（現金または電子決済）</li>
                    </ul>
                </div>
                <div class="modal-notes">
                    <h4>ご注意</h4>
                    <ul>
                        <li>申請には本人確認が必要です</li>
                        <li>代理申請の場合は委任状が必要です</li>
                        <li>申請書は正確に記入してください</li>
                        <li>不明な点は事前に窓口までお問い合わせください</li>
                    </ul>
                </div>
            `;
            
            // オンライン申請ボタンの設定
            if (onlineAvailable && onlineBtn) {
                modalOnlineBtn.style.display = 'inline-flex';
                modalOnlineBtn.onclick = function() {
                    window.location.href = onlineBtn.href;
                };
            } else {
                modalOnlineBtn.style.display = 'none';
            }
            
            // ダウンロードボタンの設定
            if (downloadBtn) {
                modalDownloadBtn.style.display = 'inline-flex';
                const pdfFile = downloadBtn.getAttribute('data-pdf');
                modalDownloadBtn.onclick = function() {
                    // 実際のサイトではPDFファイルへのリンクに変更
                    alert(`「${title}」の申請書をダウンロードします。\n（実際のサイトではPDFファイルがダウンロードされます。）`);
                    // window.location.href = `downloads/${pdfFile}`;
                };
            } else {
                modalDownloadBtn.style.display = 'none';
            }
            
            // モーダルを表示
            modal.classList.add('active');
            document.body.style.overflow = 'hidden';
        });
    });
    
    // モーダルを閉じる
    modalClose.addEventListener('click', function() {
        modal.classList.remove('active');
        document.body.style.overflow = 'auto';
    });
    
    // モーダルの外側をクリックして閉じる
    modal.addEventListener('click', function(e) {
        if (e.target === modal) {
            modal.classList.remove('active');
            document.body.style.overflow = 'auto';
        }
    });
    
    // FAQアコーディオン
    const faqQuestions = document.querySelectorAll('.faq-question');
    
    faqQuestions.forEach(question => {
        question.addEventListener('click', function() {
            const answer = this.nextElementSibling;
            const isActive = this.classList.contains('active');
            
            // すべてのFAQを閉じる
            faqQuestions.forEach(q => {
                q.classList.remove('active');
                q.nextElementSibling.classList.remove('active');
            });
            
            // クリックしたFAQを開く/閉じる
            if (!isActive) {
                this.classList.add('active');
                answer.classList.add('active');
            }
        });
    });
    
    // ダウンロードボタンの処理（ダウンロードページへのリダイレクト）
    const downloadBtns = document.querySelectorAll('a[data-pdf]');
    downloadBtns.forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            const pdfName = this.getAttribute('data-pdf');
            const procedureName = this.closest('.procedure-item').querySelector('h3').textContent;
            
            // 確認メッセージ
            const confirmDownload = confirm(`「${procedureName}」の申請書をダウンロードしますか？\n\nPDFファイルがダウンロードされます。`);
            
            if (confirmDownload) {
                // 実際のサイトではPDFへのリンクに変更
                // this.href = `downloads/${pdfName}`;
                // return true;
                
                // デモ用のメッセージ
                alert(`「${procedureName}」の申請書をダウンロードします。\n\n（デモサイトのため、実際のダウンロードは行われません。）`);
            }
        });
    });
    
    // 人気の申請手続きを動的に生成
    const popularProcedures = [
        {
            title: "住民票の写し",
            description: "住所・氏名などの証明に",
            icon: "fa-file-contract",
            category: "住民関連"
        },
        {
            title: "印鑑登録",
            description: "実印の登録・証明書発行",
            icon: "fa-stamp",
            category: "住民関連"
        },
        {
            title: "自動車登録",
            description: "自動車の新規登録・変更",
            icon: "fa-car",
            category: "自動車・交通"
        },
        {
            title: "パスポート申請",
            description: "旅券（パスポート）の新規発給",
            icon: "fa-passport",
            category: "その他"
        }
    ];
    
    const proceduresGrid = document.querySelector('.procedures-grid');
    
    if (proceduresGrid) {
        popularProcedures.forEach(procedure => {
            const card = document.createElement('div');
            card.className = 'popular-procedure-card';
            card.innerHTML = `
                <div class="procedure-icon">
                    <i class="fas ${procedure.icon}"></i>
                </div>
                <h3>${procedure.title}</h3>
                <p>${procedure.description}</p>
                <div class="procedure-category">
                    <span class="category-tag">${procedure.category}</span>
                </div>
                <button class="btn btn-primary" style="margin-top: 1rem; width: 100%;">
                    <i class="fas fa-info-circle"></i> 詳細を見る
                </button>
            `;
            
            proceduresGrid.appendChild(card);
            
            // 詳細ボタンにイベントリスナーを追加
            const detailBtn = card.querySelector('.btn');
            detailBtn.addEventListener('click', function() {
                // 検索を実行して該当の申請を表示
                searchInput.value = procedure.title;
                searchProcedures(procedure.title);
                
                // 該当の申請までスクロール
                setTimeout(() => {
                    const targetItem = document.querySelector(`.procedure-item h3:contains("${procedure.title}")`);
                    if (targetItem) {
                        targetItem.closest('.procedure-item').scrollIntoView({
                            behavior: 'smooth',
                            block: 'center'
                        });
                    }
                }, 100);
            });
        });
    }
    
    // カテゴリカードのクリックイベント
    const categoryCards = document.querySelectorAll('.category-card');
    categoryCards.forEach(card => {
        card.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href').substring(1);
            const targetSection = document.getElementById(targetId);
            
            if (targetSection) {
                // 該当セクションまでスクロール
                targetSection.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
                
                // セクションをハイライト
                targetSection.style.backgroundColor = 'var(--light-blue)';
                targetSection.style.transition = 'background-color 0.5s';
                setTimeout(() => {
                    targetSection.style.backgroundColor = '';
                }, 2000);
            }
        });
    });
    
    // 緊急情報クリック
    const emergencyAlert = document.getElementById('emergencyAlert');
    if (emergencyAlert) {
        emergencyAlert.addEventListener('click', function() {
            alert('【緊急連絡】\n\n申請手続きに関する緊急情報はありません。\n通常通り業務を行っております。');
        });
    }
    
    // 検索ボタン
    const globalSearchBtn = document.getElementById('searchBtn');
    if (globalSearchBtn) {
        globalSearchBtn.addEventListener('click', function() {
            searchInput.focus();
        });
    }
    
    // 多言語ボタン
    const languageBtn = document.getElementById('languageBtn');
    if (languageBtn) {
        languageBtn.addEventListener('click', function() {
            alert('多言語対応ページに移動します。\n（現在準備中です。）');
        });
    }
    
    // 申請手続きの表示を初期化
    function initializeProcedures() {
        // ランダムな順序で表示（デモ用）
        const items = Array.from(procedureItems);
        items.sort(() => Math.random() - 0.5);
        
        const container = document.querySelector('.procedure-items');
        if (container) {
            container.innerHTML = '';
            items.forEach(item => container.appendChild(item));
        }
    }
    
    // 初期化を実行
    initializeProcedures();
});

/* オンライン申請ページ */
.online-apply-container {
    display: grid;
    grid-template-columns: 1fr 300px;
    gap: 3rem;
    margin: 3rem 0;
}

.apply-steps {
    grid-column: 1 / -1;
    display: flex;
    justify-content: space-between;
    margin-bottom: 3rem;
}

.step {
    flex: 1;
    display: flex;
    align-items: center;
    opacity: 0.5;
    transition: all 0.3s;
}

.step.active {
    opacity: 1;
}

.step-number {
    width: 40px;
    height: 40px;
    background-color: var(--light-gray);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
    color: var(--dark-gray);
    margin-right: 15px;
    flex-shrink: 0;
}

.step.active .step-number {
    background-color: var(--primary-blue);
    color: white;
}

.step-content h3 {
    font-size: 1.1rem;
    margin-bottom: 5px;
}

.step-content p {
    font-size: 0.9rem;
    color: #666;
}

.apply-form {
    background: white;
    padding: 2rem;
    border-radius: 12px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.08);
}

.form-group {
    margin-bottom: 1.5rem;
}

.form-group label {
    display: block;
    margin-bottom: 8px;
    font-weight: 600;
    color: var(--dark-gray);
}

.form-select,
.form-input,
.form-textarea {
    width: 100%;
    padding: 12px 15px;
    border: 2px solid #ddd;
    border-radius: 6px;
    font-size: 1rem;
    transition: all 0.3s;
}

.form-select:focus,
.form-input:focus,
.form-textarea:focus {
    outline: none;
    border-color: var(--primary-blue);
    box-shadow: 0 0 0 3px rgba(0, 102, 165, 0.1);
}

.form-textarea {
    resize: vertical;
    min-height: 100px;
}

.form-help {
    display: block;
    margin-top: 5px;
    font-size: 0.85rem;
    color: #666;
}

.form-actions {
    display: flex;
    justify-content: space-between;
    margin-top: 2rem;
    padding-top: 1.5rem;
    border-top: 1px solid #eee;
}

.apply-info {
    background: white;
    padding: 2rem;
    border-radius: 12px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.08);
    align-self: start;
}

.apply-info h3 {
    color: var(--primary-blue);
    margin-bottom: 1.5rem;
    display: flex;
    align-items: center;
    gap: 10px;
}

.info-box {
    background-color: var(--light-gray);
    padding: 1.5rem;
    border-radius: 8px;
    margin-bottom: 1.5rem;
}

.info-box h4 {
    color: var(--primary-blue);
    margin-bottom: 1rem;
    font-size: 1.1rem;
}

.info-box ul {
    margin-left: 1.5rem;
    color: #555;
}

.info-box li {
    margin-bottom: 0.5rem;
}

.info-box.warning {
    background-color: #fff8e1;
    border-left: 4px solid var(--accent-yellow);
}

@media (max-width: 992px) {
    .online-apply-container {
        grid-template-columns: 1fr;
    }
    
    .apply-steps {
        flex-direction: column;
        gap: 1.5rem;
    }
    
    .step {
        width: 100%;
    }
}